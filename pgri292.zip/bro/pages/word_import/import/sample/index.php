<?php 
exit('permission denied');
?>